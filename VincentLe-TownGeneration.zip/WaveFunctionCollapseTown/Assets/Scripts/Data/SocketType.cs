namespace Didionysymus.WaveFunctionCollapse.Data
{
    public enum SocketType
    {
        Road,
        NoRoad,
        Empty,
        BuildingWall,
        BuildingDoor,
        TownWall,
        TownGate
    }
}
