namespace Didionysymus.WaveFunctionCollapse.Core
{
    public enum TileCategory
    {
        Road,
        ResidentialBuilding,
        CommercialBuilding,
        PublicBuilding,
        OpenSpace,
        Decoration,
        Wall,
        Special
    }
}