using UnityEngine;

namespace Didionysymus.DungeonGeneration.LSystem
{
    /// <summary>
    /// Represents the configuration for procedurally generating a dungeon using an L-System approach
    /// </summary>
    [CreateAssetMenu(fileName = "DungeonConfig", menuName = "L-System/Dungeon Config")]
    public class DungeonConfig : ScriptableObject
    {
        [Header("Generation Settings")] 
        [Tooltip("Random seed for generation (0 = random)")]
        public int Seed = 0;
        public int Iterations = 3;
        
        [Header("Room Settings")]
        public Vector2Int MinRoomSize = new Vector2Int(3, 3);
        public Vector2Int MaxRoomSize = new Vector2Int(7, 7);
        public float SmallRoomChance = 0.5f;
        public float MediumRoomChance = 0.35f;
        public float LargeRoomChance = 0.15f;
        [Range(0f, 1f)] public float DoorChance = 0.5f; 
        
        [Header("Special Rooms")]
        public int BossRoomCount = 1;
        public int TreasureRoomCount = 2;
        public int SafeRoomCount = 2;
        
        [Header("Corridor Settings")]
        public int MinCorridorLength = 3;
        public int MaxCorridorLength = 6;
        
        [Header("Physical Dimensions")]
        public Vector2Int MaxGridSize = new Vector2Int(50, 50);
        [Tooltip("The size of one grid cell in world units")]
        public float CellSize = 1f;
        public float FloorHeightCells = 3f;
        public float FloorHeightUnits => FloorHeightCells * CellSize;
        
        [Header("L-System Grammar")]
        [Tooltip("Custom Axiom (starting symbol) - leave empty for default")]
        public string CustomAxiom = "";
        
        [Tooltip("Enable Debug Visualization")]
        public bool Debug = true;
    }
}
